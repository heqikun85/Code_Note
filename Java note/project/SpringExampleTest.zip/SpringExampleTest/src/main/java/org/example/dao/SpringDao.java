package org.example.dao;

public interface SpringDao {
    public void save();

}
