package org.example.service;

public interface SpringService {
    public void save();
}
